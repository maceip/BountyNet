/**
 * ExecutionLog.tsx
 * Real-time log of tool calls and autonomous actions.
 */
import React, { useState, useEffect } from 'react';
import { Terminal, Play, CheckCircle2, AlertCircle, Loader2, ChevronRight } from 'lucide-react';
import { toolService, ToolCall } from '../services/tool.service';

export const ExecutionLog: React.FC = () => {
  const [calls, setCalls] = useState<ToolCall[]>([]);

  useEffect(() => {
    return toolService.subscribe(setCalls);
  }, []);

  if (calls.length === 0) return null;

  return (
    <div className="flex flex-col gap-2 bg-[#1d1f21] rounded-xl border border-slate-800 overflow-hidden shadow-2xl">
      <div className="flex items-center gap-2 px-4 py-2 bg-slate-900 border-bottom border-slate-800">
        <Terminal className="w-4 h-4 text-blue-400" />
        <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Autonomous Execution Log</span>
      </div>
      
      <div className="flex flex-col max-h-[300px] overflow-y-auto p-2 font-mono text-sm">
        {calls.map((call) => (
          <div key={call.id} className="group flex flex-col gap-1 p-2 rounded hover:bg-slate-800/50 transition-colors">
            <div className="flex items-center gap-3">
              <span className="text-slate-500 text-[10px]">
                {new Date(call.timestamp).toLocaleTimeString([], { hour12: false })}
              </span>
              
              <div className="flex items-center gap-2 flex-1">
                {call.status === 'running' && <Loader2 className="w-3.5 h-3.5 text-blue-400 animate-spin" />}
                {call.status === 'success' && <CheckCircle2 className="w-3.5 h-3.5 text-green-500" />}
                {call.status === 'error' && <AlertCircle className="w-3.5 h-3.5 text-red-500" />}
                {call.status === 'pending' && <Play className="w-3.5 h-3.5 text-slate-500" />}
                
                <span className={
                  call.status === 'running' ? 'text-blue-300' : 
                  call.status === 'success' ? 'text-green-400' : 
                  'text-slate-300'
                }>
                  {call.toolName}
                </span>
                
                <ChevronRight className="w-3 h-3 text-slate-600" />
                
                <span className="text-slate-500 truncate text-xs">
                  {JSON.stringify(call.arguments)}
                </span>
              </div>

              {call.status === 'pending' && (
                <button 
                  onClick={() => toolService.execute(call.id)}
                  className="px-2 py-0.5 bg-blue-600 text-[10px] text-white rounded hover:bg-blue-500 transition-colors"
                >
                  APPROVE
                </button>
              )}
            </div>
            
            {call.result && (
              <div className="ml-16 p-2 bg-black/30 rounded border-l-2 border-slate-700 text-slate-400 text-[11px] whitespace-pre-wrap">
                {JSON.stringify(call.result, null, 2)}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
