/**
 * DiffEditor.tsx
 * High-fidelity, side-by-side code diffs using the Monaco Diff Editor.
 * Replicates the "swebot-diff-viewer" recovered plumbing.
 */
import React from 'react';
import { DiffEditor as MonacoDiffEditor, OnMount } from '@monaco-editor/react';

interface DiffEditorProps {
  original: string;
  modified: string;
  fileName: string;
  language?: string;
}

export const DiffEditor: React.FC<DiffEditorProps> = ({ 
  original, 
  modified, 
  fileName, 
  language 
}) => {
  
  // Reuse language detection logic
  const detectLanguage = (name: string) => {
    const ext = name.split('.').pop()?.toLowerCase();
    switch (ext) {
      case 'ts':
      case 'tsx': return 'typescript';
      case 'js':
      case 'jsx': return 'javascript';
      case 'py': return 'python';
      default: return 'text';
    }
  };

  const handleEditorDidMount: OnMount = (editor, monaco) => {
    // Custom Diff Configuration (Option Champagne)
    editor.getModifiedEditor().updateOptions({
      fontSize: 14,
      fontFamily: "'JetBrains Mono', 'Fira Code', monospace",
      minimap: { enabled: false },
      automaticLayout: true,
      renderSideBySide: true, // Default to side-by-side
      ignoreTrimWhitespace: false,
    });
  };

  return (
    <div className="flex flex-col h-full bg-[#1e1e1e] rounded-xl border border-slate-800 overflow-hidden shadow-2xl">
      {/* Header with Diff Controls */}
      <div className="flex items-center justify-between px-4 py-2 bg-[#252526] border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-orange-500/50" />
          <span className="text-xs font-medium text-slate-400 font-mono">Comparing: {fileName}</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">
            {language || detectLanguage(fileName)}
          </span>
          <div className="flex bg-[#333333] rounded p-0.5">
             <button className="px-2 py-0.5 text-[10px] bg-[#555555] text-white rounded shadow-sm">Side-by-Side</button>
             <button className="px-2 py-0.5 text-[10px] text-slate-400 hover:text-white transition-colors">Inline</button>
          </div>
        </div>
      </div>
      
      <div className="flex-1">
        <MonacoDiffEditor
          height="100%"
          original={original}
          modified={modified}
          language={language || detectLanguage(fileName)}
          theme="vs-dark"
          onMount={handleEditorDidMount}
        />
      </div>
    </div>
  );
};
