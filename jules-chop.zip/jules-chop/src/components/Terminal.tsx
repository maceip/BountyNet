/**
 * Terminal.tsx
 * High-performance, scrolling terminal for live code execution output.
 * Replicates the "swebot-terminal" recovered plumbing.
 */
import React, { useRef, useEffect } from 'react';
import { Terminal as TerminalIcon, Hash, Copy, Trash2 } from 'lucide-react';

interface LogEntry {
  type: 'stdout' | 'stderr' | 'system';
  content: string;
  timestamp: number;
}

interface TerminalProps {
  logs: LogEntry[];
  onClear: () => void;
}

export const Terminal: React.FC<TerminalProps> = ({ logs, onClear }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom on new logs
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  return (
    <div className="flex flex-col h-64 bg-[#0c0c0c] border border-slate-800 rounded-xl overflow-hidden shadow-2xl font-mono">
      {/* Terminal Header */}
      <div className="flex items-center justify-between px-4 py-2 bg-[#1a1a1a] border-b border-slate-800">
        <div className="flex items-center gap-2">
          <TerminalIcon className="w-3.5 h-3.5 text-blue-400" />
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Secure Runtime Terminal</span>
        </div>
        <div className="flex items-center gap-3">
          <button className="text-slate-500 hover:text-white transition-colors"><Copy className="w-3 h-3" /></button>
          <button onClick={onClear} className="text-slate-500 hover:text-red-400 transition-colors"><Trash2 className="w-3 h-3" /></button>
        </div>
      </div>

      {/* Terminal Body */}
      <div 
        ref={scrollRef}
        className="flex-1 p-4 overflow-y-auto text-sm leading-relaxed"
      >
        {logs.length === 0 && (
          <div className="flex items-center gap-2 text-slate-600 italic">
            <Hash className="w-3.5 h-3.5" />
            <span>Awaiting execution output...</span>
          </div>
        )}
        
        {logs.map((log, i) => (
          <div key={i} className="flex gap-3 group">
            <span className="text-slate-600 select-none w-4 text-right">{i + 1}</span>
            <span className={`
              ${log.type === 'stderr' ? 'text-red-400' : ''}
              ${log.type === 'system' ? 'text-blue-400 font-bold' : 'text-slate-300'}
              whitespace-pre-wrap break-all
            `}>
              {log.content}
            </span>
          </div>
        ))}
        
        {/* Cursor Placeholder */}
        <div className="flex items-center gap-2 text-blue-400 animate-pulse mt-2">
          <span className="font-bold">❯</span>
          <div className="w-2 h-4 bg-blue-400" />
        </div>
      </div>
    </div>
  );
};
