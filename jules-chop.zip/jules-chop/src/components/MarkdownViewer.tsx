/**
 * MarkdownViewer.tsx
 * High-performance, secure Markdown renderer.
 * Replaces the 1.5MB jukeswasm (CMark/RE2) with modern libraries.
 */
import React, { useMemo, useEffect } from 'react';
import MarkdownIt from 'markdown-it';
import Prism from 'prismjs';

// Load Prism languages (extensible)
import 'prismjs/components/prism-typescript';
import 'prismjs/components/prism-javascript';
import 'prismjs/components/prism-python';
import 'prismjs/components/prism-json';
import 'prismjs/components/prism-bash';
import 'prismjs/themes/prism-tomorrow.css'; // Dark theme for code blocks

interface MarkdownViewerProps {
  content: string;
}

export const MarkdownViewer: React.FC<MarkdownViewerProps> = ({ content }) => {
  const md = useMemo(() => {
    return new MarkdownIt({
      html: false, // Security: Always escape HTML
      linkify: true,
      typographer: true,
      highlight: (code, lang) => {
        if (lang && Prism.languages[lang]) {
          try {
            return `<pre class="language-${lang}"><code>${Prism.highlight(
              code,
              Prism.languages[lang],
              lang
            )}</code></pre>`;
          } catch (err) {
            console.error('Prism highlight error:', err);
          }
        }
        return `<pre class="language-text"><code>${md.utils.escapeHtml(code)}</code></pre>`;
      }
    });
  }, []);

  // Re-run highlighting on content change (for dynamic updates)
  useEffect(() => {
    Prism.highlightAll();
  }, [content]);

  const htmlContent = md.render(content);

  return (
    <div className="markdown-container">
      <div 
        className="prose prose-slate max-w-none 
                   prose-headings:text-slate-800 prose-headings:font-bold
                   prose-p:text-slate-600 prose-p:leading-relaxed
                   prose-code:bg-slate-100 prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded prose-code:text-blue-600
                   prose-pre:bg-[#1d1f21] prose-pre:rounded-xl prose-pre:shadow-lg prose-pre:p-4
                   prose-a:text-blue-600 prose-a:no-underline hover:prose-a:underline"
        dangerouslySetInnerHTML={{ __html: htmlContent }} 
      />
    </div>
  );
};
