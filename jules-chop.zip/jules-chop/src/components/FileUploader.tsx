/**
 * FileUploader.tsx
 * Industrial-grade directory uploader using the File System Access API.
 */
import React, { useState } from 'react';
import { Upload, Folder, FileCheck, Loader2 } from 'lucide-react';
import { zipService, FileData } from '../services/zip.service';

interface FileUploaderProps {
  onPackageReady: (blob: Blob, taskId: string) => void;
}

export const FileUploader: React.FC<FileUploaderProps> = ({ onPackageReady }) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [fileCount, setFileCount] = useState(0);

  const handleDirectorySelect = async () => {
    try {
      // 1. Open Directory Picker (Modern Browsers)
      // @ts-ignore - showDirectoryPicker is a modern API
      const dirHandle = await window.showDirectoryPicker();
      setIsProcessing(true);
      
      const files: FileData[] = [];
      const taskId = `task_${Date.now()}`;

      // 2. Recursive File Walk
      const readDir = async (handle: any, path = '') => {
        for await (const entry of handle.values()) {
          const entryPath = path ? `${path}/${entry.name}` : entry.name;
          
          if (entry.kind === 'directory') {
            await readDir(entry, entryPath);
          } else {
            const file = await entry.getFile();
            // Basic filtering (ignore .git, node_modules)
            if (!entryPath.includes('.git/') && !entryPath.includes('node_modules/')) {
              const content = await file.text();
              files.push({ path: entryPath, content });
            }
          }
        }
      };

      await readDir(dirHandle);
      setFileCount(files.length);

      // 3. Hand off to Worker for Zipping
      const zipBlob = await zipService.packageRepository(taskId, files);
      
      onPackageReady(zipBlob, taskId);
      setIsProcessing(false);
    } catch (err) {
      console.error('Directory upload failed:', err);
      setIsProcessing(false);
    }
  };

  return (
    <div className="p-8 border-2 border-dashed border-slate-300 rounded-xl bg-slate-50 flex flex-col items-center justify-center gap-4 hover:border-blue-400 transition-colors">
      {isProcessing ? (
        <>
          <Loader2 className="w-12 h-12 text-blue-500 animate-spin" />
          <div className="text-center">
            <p className="font-semibold text-slate-700">Packaging Repository...</p>
            <p className="text-sm text-slate-500">{fileCount} files identified</p>
          </div>
        </>
      ) : (
        <>
          <div className="p-4 bg-blue-100 rounded-full">
            <Folder className="w-10 h-10 text-blue-600" />
          </div>
          <div className="text-center">
            <h3 className="text-lg font-bold text-slate-800">Upload Local Context</h3>
            <p className="text-sm text-slate-500 mb-4">Select a directory to shard and send for analysis</p>
            <button
              onClick={handleDirectorySelect}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 active:scale-95 transition-all flex items-center gap-2"
            >
              <Upload className="w-4 h-4" />
              Select Directory
            </button>
          </div>
        </>
      )}
    </div>
  );
};
