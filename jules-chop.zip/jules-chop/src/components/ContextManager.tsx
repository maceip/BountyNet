/**
 * ContextManager.tsx
 * UI for managing and sharding active context items.
 */
import React, { useState, useEffect } from 'react';
import { X, FileCode, Link, Database, ShieldCheck } from 'lucide-react';
import { contextService, ContextItem } from '../services/context.service';

export const ContextManager: React.FC = () => {
  const [items, setItems] = useState<ContextItem[]>([]);

  useEffect(() => {
    return contextService.subscribe(setItems);
  }, []);

  if (items.length === 0) return null;

  return (
    <div className="flex flex-wrap gap-2 p-4 bg-slate-100 rounded-lg border border-slate-200 shadow-inner min-h-[60px]">
      {items.map(item => (
        <div 
          key={item.id}
          className="flex items-center gap-2 px-3 py-1.5 bg-white border border-blue-200 rounded-full text-sm font-medium text-slate-700 hover:border-blue-400 transition-all group"
        >
          {item.type === 'file' && <FileCode className="w-4 h-4 text-blue-500" />}
          {item.type === 'link' && <Link className="w-4 h-4 text-slate-400" />}
          {item.type === 'shard' && <ShieldCheck className="w-4 h-4 text-green-500" />}
          
          <span className="truncate max-w-[200px]">{item.name}</span>
          
          <button 
            onClick={() => contextService.removeItem(item.id)}
            className="p-0.5 hover:bg-slate-100 rounded-full group-hover:text-red-500"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      ))}
      
      {items.some(i => i.type === 'file') && (
        <div className="ml-auto flex items-center gap-2 text-xs font-bold text-blue-600 uppercase tracking-wider">
          <Database className="w-3 h-3" />
          Ready for Sharding
        </div>
      )}
    </div>
  );
};
