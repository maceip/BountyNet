/**
 * CodeEditor.tsx
 * High-performance code canvas using the Monaco Editor (VS Code Engine).
 */
import React from 'react';
import Editor, { OnMount } from '@monaco-editor/react';

interface CodeEditorProps {
  fileName?: string;
  content?: string;
  language?: string;
  readOnly?: boolean;
}

export const CodeEditor: React.FC<CodeEditorProps> = ({ 
  fileName = 'index.ts', 
  content = '// Select a file to view or edit code...', 
  language,
  readOnly = false 
}) => {
  
  // Detect language from file extension if not provided
  const detectLanguage = (name: string) => {
    const ext = name.split('.').pop()?.toLowerCase();
    switch (ext) {
      case 'ts':
      case 'tsx': return 'typescript';
      case 'js':
      case 'jsx': return 'javascript';
      case 'py': return 'python';
      case 'json': return 'json';
      case 'html': return 'html';
      case 'css': return 'css';
      case 'md': return 'markdown';
      case 'rs': return 'rust';
      case 'go': return 'go';
      case 'cpp':
      case 'cc':
      case 'h': return 'cpp';
      default: return 'text';
    }
  };

  const handleEditorDidMount: OnMount = (editor, monaco) => {
    // Custom Monaco Configuration (Option Champagne)
    editor.updateOptions({
      fontSize: 14,
      fontFamily: "'JetBrains Mono', 'Fira Code', monospace",
      minimap: { enabled: true },
      scrollBeyondLastLine: false,
      automaticLayout: true,
      padding: { top: 16, bottom: 16 },
      lineNumbersMinChars: 3,
      glyphMargin: true,
      folding: true,
      links: true,
    });
  };

  return (
    <div className="flex flex-col h-full bg-[#1e1e1e] rounded-xl border border-slate-800 overflow-hidden shadow-2xl">
      <div className="flex items-center justify-between px-4 py-2 bg-[#252526] border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-blue-500/50" />
          <span className="text-xs font-medium text-slate-400 font-mono">{fileName}</span>
        </div>
        <div className="flex items-center gap-4 text-[10px] text-slate-500 uppercase font-bold tracking-wider">
          <span>UTF-8</span>
          <span>{language || detectLanguage(fileName)}</span>
        </div>
      </div>
      
      <div className="flex-1">
        <Editor
          height="100%"
          defaultLanguage={language || detectLanguage(fileName)}
          defaultValue={content}
          theme="vs-dark"
          options={{ readOnly }}
          onMount={handleEditorDidMount}
        />
      </div>
    </div>
  );
};
