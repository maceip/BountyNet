/**
 * zip.worker.ts
 * The "Forge": Packages the Bootstrap repo and partitions it for the compute cluster.
 */
import JSZip from 'jszip';
import { DataPartitioner } from '../extracted_logic/data_partitioner.js';

self.onmessage = async (e: MessageEvent) => {
  const { files, taskId, clusterConfig } = e.data;
  const zip = new JSZip();

  console.log(`[Worker] Bootstrapping repository for Task ${taskId}...`);

  for (const file of files) {
    zip.file(file.path, file.content);
  }

  try {
    const fullZipBlob = await zip.generateAsync({ type: 'uint8array' });
    
    console.log(`[Worker] Partitioning ${fullZipBlob.length} bytes for compute cluster...`);
    
    // Cluster Configuration (t, n)
    const { t, n } = clusterConfig || { t: 3, n: 5 };
    
    // Demonstrate partitioning of the task descriptor
    const partitions = DataPartitioner.createPartitions(taskId, t, n);

    self.postMessage({ 
      status: 'complete', 
      partitions, 
      taskId,
      originalSize: fullZipBlob.length 
    });
  } catch (error) {
    self.postMessage({ status: 'error', error: error.message, taskId });
  }
};
