/**
 * tool.service.ts
 * Orchestrates tool calling and autonomous execution.
 */

export interface ToolCall {
  id: string;
  toolName: string;
  arguments: any;
  status: 'pending' | 'running' | 'success' | 'error';
  result?: any;
  timestamp: number;
}

class ToolService {
  private calls: ToolCall[] = [];
  private listeners: Set<(calls: ToolCall[]) => void> = new Set();

  registerCall(toolName: string, args: any): string {
    const id = `call_${Date.now()}`;
    const newCall: ToolCall = {
      id,
      toolName,
      arguments: args,
      status: 'pending',
      timestamp: Date.now()
    };
    this.calls.unshift(newCall); // Newest first
    this.notify();
    return id;
  }

  updateStatus(id: string, status: ToolCall['status'], result?: any) {
    const call = this.calls.find(c => c.id === id);
    if (call) {
      call.status = status;
      if (result) call.result = result;
      this.notify();
    }
  }

  getCalls(): ToolCall[] {
    return [...this.calls];
  }

  subscribe(listener: (calls: ToolCall[]) => void) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach(l => l(this.getCalls()));
  }

  /**
   * Mock Execution - This will eventually be handled by the MPC cluster.
   */
  async execute(id: string) {
    const call = this.calls.find(c => c.id === id);
    if (!call) return;

    this.updateStatus(id, 'running');
    
    // Simulate autonomous execution in the "Secure VM"
    return new Promise((resolve) => {
      setTimeout(() => {
        console.log(`[MPC Executor] Finished ${call.toolName}`);
        this.updateStatus(id, 'success', { message: "Execution complete", code: 0 });
        resolve(true);
      }, 1500);
    });
  }
}

export const toolService = new ToolService();
