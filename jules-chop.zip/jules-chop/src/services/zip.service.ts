/**
 * zip.service.ts
 * Manages communication with the ZipWorker.
 */

export interface FileData {
  path: string;
  content: string | Uint8Array;
}

export interface ZipResult {
  status: 'complete' | 'error';
  blob?: Blob;
  error?: string;
  taskId: string;
}

class ZipService {
  private worker: Worker;
  private pendingTasks: Map<string, (result: ZipResult) => void> = new Map();

  constructor() {
    // Note: In a Vite environment, this URL will be correctly handled
    this.worker = new Worker(new URL('../workers/zip.worker.ts', import.meta.url), {
      type: 'module'
    });

    this.worker.onmessage = (e: MessageEvent<ZipResult>) => {
      const { taskId } = e.data;
      const resolver = this.pendingTasks.get(taskId);
      if (resolver) {
        resolver(e.data);
        this.pendingTasks.delete(taskId);
      }
    };
  }

  async packageRepository(taskId: string, files: FileData[]): Promise<Blob> {
    return new Promise((resolve, reject) => {
      this.pendingTasks.set(taskId, (result) => {
        if (result.status === 'complete' && result.blob) {
          resolve(result.blob);
        } else {
          reject(new Error(result.error || 'Unknown zipping error'));
        }
      });

      this.worker.postMessage({ taskId, files });
    });
  }
}

export const zipService = new ZipService();
