/**
 * context.service.ts
 * The "Brain" for managing active task context.
 */

export interface ContextItem {
  id: string;
  type: 'file' | 'issue' | 'link' | 'shard';
  name: string;
  payload: any;
}

class ContextService {
  private activeItems: Map<string, ContextItem> = new Map();
  private listeners: Set<(items: ContextItem[]) => void> = new Set();

  addItem(item: ContextItem) {
    this.activeItems.set(item.id, item);
    this.notify();
  }

  removeItem(id: string) {
    this.activeItems.delete(id);
    this.notify();
  }

  getItems(): ContextItem[] {
    return Array.from(this.activeItems.values());
  }

  subscribe(listener: (items: ContextItem[]) => void) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    const items = this.getItems();
    this.listeners.forEach(l => l(items));
  }

  /**
   * Prepares the context for the "CreateTask" RPC call.
   * Maps items to the recovered field tags (Field 13 for metadata).
   */
  prepareForRpc() {
    return this.getItems().map(item => ({
      tag: 13,
      value: {
        id: item.id,
        type: item.type,
        displayName: item.name
      }
    }));
  }
}

export const contextService = new ContextService();
