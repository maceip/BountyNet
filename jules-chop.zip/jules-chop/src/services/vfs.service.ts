/**
 * vfs.service.ts
 * Virtual File System for managing local code context securely.
 * Replicates the "StatefulExecutionInterface" plumbing.
 */

export interface VfsNode {
  path: string;
  content: string;
  isDirty: boolean; // Has the bot modified this locally?
  handleId?: string; // The opaque MPC handle
}

class VfsService {
  private nodes: Map<string, VfsNode> = new Map();
  private listeners: Set<(nodes: VfsNode[]) => void> = new Set();

  /**
   * Syncs a local file into the Virtual File System.
   * This is where the "Sensitive" data enters the system.
   */
  syncFile(path: string, content: string) {
    const node: VfsNode = {
      path,
      content,
      isDirty: false,
      handleId: `handle_${Math.random().toString(36).substr(2, 9)}`
    };
    this.nodes.set(path, node);
    this.notify();
  }

  /**
   * Applies a "High-Fidelity Diff" to the local VFS.
   * This happens when you "Accept" a bot's proposed fix.
   */
  applyPatch(path: string, newContent: string) {
    const node = this.nodes.get(path);
    if (node) {
      node.content = newContent;
      node.isDirty = true;
      this.notify();
    }
  }

  getNodes(): VfsNode[] {
    return Array.from(this.nodes.values());
  }

  subscribe(listener: (nodes: VfsNode[]) => void) {
    this.listeners.add(listener);
    return () => this.listeners.delete(this.getNodes());
  }

  private notify() {
    this.listeners.forEach(l => l(this.getNodes()));
  }
}

export const vfsService = new VfsService();
