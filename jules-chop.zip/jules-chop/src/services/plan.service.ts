/**
 * plan.service.ts
 * Manages bot-generated plans and their associated code diffs.
 */

export interface PlanStep {
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'accepted' | 'rejected';
  diff?: {
    fileName: string;
    original: string;
    modified: string;
  };
}

class PlanService {
  private steps: PlanStep[] = [];
  private listeners: Set<(steps: PlanStep[]) => void> = new Set();

  setSteps(steps: PlanStep[]) {
    this.steps = steps;
    this.notify();
  }

  acceptStep(id: string) {
    const step = this.steps.find(s => s.id === id);
    if (step) {
      step.status = 'accepted';
      this.notify();
    }
  }

  getSteps(): PlanStep[] {
    return [...this.steps];
  }

  subscribe(listener: (steps: PlanStep[]) => void) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach(l => l(this.getSteps()));
  }
}

export const planService = new PlanService();
