/**
 * handle.service.ts
 * Manages the "Opaque Handles" for sensitive context.
 * This is the bridge to the MPCAuth system.
 */

export interface ContextHandle {
  id: string;
  type: 'identity' | 'code' | 'token';
  isSharded: boolean;
}

class HandleRegistry {
  private handles: Map<string, ContextHandle> = new Map();

  /**
   * Registers a piece of sensitive context and returns an opaque ID.
   * The actual data stays in the VFS or is sharded via MPC.
   */
  register(type: ContextHandle['type']): string {
    const id = `hdl_${crypto.randomUUID()}`;
    this.handles.set(id, {
      id,
      type,
      isSharded: false // Will be set to true by MPCAuth_SSS
    });
    return id;
  }

  getHandle(id: string) {
    return this.handles.get(id);
  }

  /**
   * This is all the Bot (LLM) ever sees.
   */
  getBotView() {
    return Array.from(this.handles.values()).map(h => ({
      handleId: h.id,
      description: `Secure ${h.type} context`
    }));
  }
}

export const handleRegistry = new HandleRegistry();
