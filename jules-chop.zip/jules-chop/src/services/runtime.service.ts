/**
 * runtime.service.ts
 * Manages the "Secure VM" lifecycle and stdout/stderr streaming.
 */

export interface ExecutionResult {
  stdout: string;
  stderr: string;
  exitCode: number;
}

class RuntimeService {
  private logListeners: Set<(type: 'stdout' | 'stderr' | 'system', content: string) => void> = new Set();

  onLog(listener: (type: 'stdout' | 'stderr' | 'system', content: string) => void) {
    this.logListeners.add(listener);
    return () => this.logListeners.delete(listener);
  }

  private emit(type: 'stdout' | 'stderr' | 'system', content: string) {
    this.logListeners.forEach(l => l(type, content));
  }

  /**
   * Provisions the Secure VM (The "Raise Inference Server" plumbing).
   */
  async provision() {
    this.emit('system', 'Provisioning Secure Execution Environment...');
    await new Promise(r => setTimeout(r, 800));
    this.emit('system', 'Environment Ready. Isolated VM connected.');
  }

  /**
   * Executes code in the provisioned environment.
   */
  async runCommand(command: string, args: string[]) {
    this.emit('system', `Running: ${command} ${args.join(' ')}`);
    
    // Simulate streaming output
    await new Promise(r => setTimeout(r, 500));
    this.emit('stdout', `[INFO] Initializing test suite...`);
    
    await new Promise(r => setTimeout(r, 1000));
    this.emit('stdout', `[PASS] context.service.spec.ts (12 tests)`);
    this.emit('stdout', `[PASS] zip.worker.spec.ts (5 tests)`);
    
    await new Promise(r => setTimeout(r, 500));
    this.emit('system', `Command finished with exit code 0`);
  }
}

export const runtimeService = new RuntimeService();
