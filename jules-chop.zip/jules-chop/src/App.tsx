/**
 * App.tsx
 * The "Bountynet" S.W.E. Bot Dashboard.
 * Focus: High-Performance Distributed Architecture.
 */
import React, { useState } from 'react';
import { Sparkles, Layout, Settings, Github, Cpu, Activity } from 'lucide-react';
import { FileUploader } from './components/FileUploader';
import { ContextManager } from './components/ContextManager';
import { CodeEditor } from './components/CodeEditor';
import { MarkdownViewer } from './components/MarkdownViewer';
import { ExecutionLog } from './components/ExecutionLog';

const App: React.FC = () => {
  const [taskContent] = useState<string>(`
# Automated Bug Fix Proposal
**Task ID:** 45746034

Analysis complete. Identified a resource leak in the **Context Dispatcher**.

### Plan:
1. Identify the leaked listener in \`context.service.ts\`.
2. Implement a proper \`unsubscribe\` cleanup method.
3. Verify the fix with a load test in the isolated runtime.

\`\`\`typescript
// Proposed Fix in context.service.ts
public subscribe(listener: Listener) {
  this.listeners.add(listener);
  return () => this.listeners.delete(listener); // Added cleanup!
}
\`\`\`
  `);

  return (
    <div className="flex flex-col h-screen bg-slate-50 text-slate-900 overflow-hidden font-sans">
      {/* 1. Header (Top Bar) */}
      <header className="h-14 bg-white border-b border-slate-200 flex items-center justify-between px-6 z-20 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-1.5 bg-blue-600 rounded-lg">
            <Cpu className="w-5 h-5 text-white" />
          </div>
          <h1 className="font-extrabold text-lg tracking-tight uppercase">BOUNTY<span className="text-blue-600">NET</span></h1>
          <div className="h-4 w-[1px] bg-slate-300 mx-2" />
          <div className="flex items-center gap-2 px-2 py-1 bg-blue-50 rounded border border-blue-100 text-[10px] font-bold text-blue-700">
            <Activity className="w-3 h-3" />
            PARALLEL CLUSTER SESSION
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <button className="p-2 hover:bg-slate-100 rounded-full text-slate-500 transition-colors">
            <Github className="w-5 h-5" />
          </button>
          <button className="p-2 hover:bg-slate-100 rounded-full text-slate-500 transition-colors">
            <Settings className="w-5 h-5" />
          </button>
          <div className="w-8 h-8 rounded-full bg-slate-200 border-2 border-white shadow-md" />
        </div>
      </header>

      {/* 2. Main Content Area */}
      <main className="flex-1 flex overflow-hidden">
        
        {/* Left Sidebar: Context & Data Ingress */}
        <aside className="w-80 border-r border-slate-200 bg-white flex flex-col gap-4 p-4 overflow-y-auto z-10">
          <FileUploader onPackageReady={(blob) => console.log('Ready for cluster partitioning:', blob)} />
          <div className="space-y-2">
            <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-2">Active Context</h4>
            <ContextManager />
          </div>
        </aside>

        {/* Center: The Code Canvas */}
        <section className="flex-1 p-4 bg-slate-100 overflow-hidden flex flex-col gap-4">
          <CodeEditor />
          <ExecutionLog />
        </section>

        {/* Right Sidebar: Analysis Stream */}
        <aside className="w-[450px] border-l border-slate-200 bg-white flex flex-col overflow-hidden">
          <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex items-center gap-2">
            <Layout className="w-4 h-4 text-blue-600" />
            <span className="font-bold text-sm">Cluster Analysis & Plan</span>
          </div>
          <div className="flex-1 overflow-y-auto p-6">
            <MarkdownViewer content={taskContent} />
          </div>
        </aside>

      </main>
    </div>
  );
};

export default App;
