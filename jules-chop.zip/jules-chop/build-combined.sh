#!/usr/bin/env bash
# Concatenate Swebot chunks in the order required by the Closure module graph.
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
OUT="${DIR}/swebot-runtime.combined.js"
cat "${DIR}/page3.js" "${DIR}/page1.js" "${DIR}/page2.js" > "${OUT}"
echo "Wrote ${OUT} ($(wc -c < "${OUT}") bytes)"
if command -v node >/dev/null 2>&1; then
  node --check "${OUT}" && echo "node --check: OK" || echo "node --check: FAILED"
fi
