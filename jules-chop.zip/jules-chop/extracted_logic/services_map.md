# SweBotService & ContextService - Decompiled Logic

This document captures the extracted RPC logic and service structures for rebuilding the prototype.

## SweBotService

Base Path: `/SweBotService`

### Methods

| Method Name | Descriptor (RPC Code) | Request Class | Response Class | Notes |
|-------------|-----------------------|---------------|----------------|-------|
| `GetProactiveSourceQuota` | `UTrvy` | `k0a` | `p0a` | |
| `GetProactiveTasksConfig` | `jWEQ2e` | `m0a` | `r0a` | |
| `GetProactivityStatus` | `xJny7c` | `pX` | `t0a` | |
| `ListProactiveSuggestions`| `hQP40d` | `_.DFa` | `v0a` | |
| `UpdateProactiveSuggestionStatus` | `sc1vFf` | `kib` | `oib` | |
| `UpdateProactivitySettings`| `e4motb` | `mib` | `sib` | |
| `ListScheduledTaskExecutions` | `z24nKf` | `_.HFa` | `upb` | |
| `ListScheduledTasks` | `hvmRxc` | `_.LFa` | `xpb` | |
| `DeleteScheduledTask` | `sL8twb` | (anon) | `Bpb` | |
| `PauseScheduledTask` | `gBUOb` | (anon) | `Epb` | |
| `ResumeScheduledTask` | `XuzQWe` | (anon) | `Hpb` | |
| `ListGitHubIssues` | `qXM1Fb` | (anon) | `Nwb` | |
| `GenerateOAuthStateToken` | `DrvqKc` | `mOa` | `oOa` | |
| `GetClientId` | `ksk7Zb` | (anon) | `qOa` | |
| `AcceptTos` | `A5O08b` | `_.cPa` | `_.DKa` | |
| `CheckTos` | `K6okqd` | `nFa` | `_.EKa` | |
| `CreateTask` | `Rja83d` | `zN` | `_.gO` | **Crucial** |
| `GetFile` | `Vw9Lvf` | `sFa` | `_.HKa` | |
| `GetNotifications` | `cFjlx` | `wFa` | `_.JKa` | |
| `GetScheduledTask` | `ulnqbc` | (anon) | (anon) | |
| `GetSource` | `pO0y2d` | `AFa` | `LKa` | |
| `GetTaskUsage` | `KQOO7` | `kO` | `jO` | |
| `GetTask` | `n74qPd` | `MN` | `lO` | |
| `GetUserGitHubAuthStatus` | `fTz0n` | `BFa` | (anon) | |
| `GetUserSettings` | `VjAv3d` | `RN` | `mO` | |
| `ListSourceTasks` | `zIqjSc` | `OFa` | `SKa` | |
| `ListSources` | `YqkSHd` | `QFa` | `KP` | |
| `ListTasks` | `p1Takd` | `TN` | `_.oO` | |
| `QuerySources` | `B4fVMb` | `UFa` | `WKa` | |
| `DeleteTasks` | `rist8` | `_.OW` | `_.QW` | |
| `ArchiveTasks` | `Tjmm5c` | (anon) | `Rob` | |
| `CheckGitHubQuota` | `gV7IZe` | `u5a` | `z5a` | |
| `ListBranchNodes` | `c9RQT` | `v5a` | `B5a` | |
| `UpdateNotifications` | `ZVF6Ae` | `x5a` | `_.zY` | |
| `ListEnvironmentVariables`| `IjaU6c` | `c7a` | `e7a` | |
| `ListAuthorizedAccounts` | `G6wZ6` | `Qcb` | `Scb` | |
| `UpdateUserSettings` | `GCDTBd` | `NW` | `MW` | |

## ContextService

Base Path: `/ContextService`

### Methods

| Method Name | Descriptor | Request Class | Response Class | Notes |
|-------------|------------|---------------|----------------|-------|
| `CompleteOAuth` | `V7QkPe` | (anon) | (anon) | |
| `GetContext` | `z0LDdf` | `_.kS` | `_.gPa` | |
| `ListToolProviders` | `fI0vqb` | (anon) | `_.lS` | |
| `ListTools` | `h2scJf` | (anon) | `_.nS` | |

## Task Status Enums (Extracted)

```javascript
_.Jy = new Map([
  [0, "Unknown"],
  [1, "Queued"],
  [11, "Queued restart"],
  [2, "In progress"],
  [9, "Planning"],
  [12, "Awaiting user feedback"],
  [10, "Awaiting plan approval"],
  [3, "Completed"],
  [4, "Error"],
  [8, "Paused"],
  [7, "Completed"]
]);
```
