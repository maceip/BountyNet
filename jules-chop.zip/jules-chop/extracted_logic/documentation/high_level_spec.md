# Bountynet System Architecture & Interface Specification
## Camera-Ready Technical Specification

This document provides a clean-room specification of the Bountynet Distributed S.W.E. platform. It defines the component boundaries, wire protocols, and data structures required for a high-fidelity implementation of the Parallel Cluster architecture.

---

## 1. System Topology

The system is organized into a **Hub-and-Spoke Distributed Trust** model:

*   **Commander (The Browser):** Orchestrates the user intent, manages local context boundaries, and performs cryptographic partitioning.
*   **The Forge (Background Worker):** A multi-threaded execution layer for non-blocking data transformations (Zipping, Fragmenting).
*   **Parallel Cluster (Remote Spoke):** A collection of $N$ independent compute nodes that jointly execute sharded tasks.
*   **Forwarder Node (The Hub):** A specialized cluster node that handles physical TCP/TLS uplinks to external services (GitHub, SMTP) via Handshake Proxying.

---

## 2. Wire Protocol: Data Forge RPC (DFRPC)

The system uses a highly optimized, array-based serialization format. This protocol prioritizes zero-copy overhead and direct mapping to cluster node memory.

### Protocol Characteristics:
*   **Transport:** HTTPS/2 + WebSockets (for bidirectional terminal streaming).
*   **Pathing:** `/api/v1/data/{ServiceName}.{MethodName}`
*   **Serialization:** Positional Array-Proto. Data is transmitted as nested arrays where index $N$ represents Field Tag $N$.
*   **Example Payload:** `[null, "task_882", "Fix memory leak", ["hdl_001"]]`

---

## 3. Remote Server Interfaces

### A. SweBotService
Primary interface for autonomous task lifecycle management.

| Method | Function | Input Type | Output Type |
|:---|:---|:---|:---|
| `CreateTask` | Initializes a partitioned compute task. | `TaskDescriptor` | `TaskState` |
| `GetTask` | Polls current progress of a specific task. | `TaskId` | `TaskState` |
| `ListTasks` | Enumerates tasks across the cluster. | `FilterQuery` | `TaskBatch` |
| `UpdateUserSettings` | Syncs localized cluster preferences. | `UserPrefs` | `SyncResult` |

### B. ContextService (MCP Gateway)
Implements the **Model Context Protocol (MCP)** for distributed tool orchestration.

| Method | Function | Input Type | Output Type |
|:---|:---|:---|:---|
| `GetContext` | Resolves handles to sharded data fragments. | `HandleRequest` | `OpaqueHandle` |
| `ListToolProviders` | Discovers available cluster compute nodes. | `DiscoveryMsg` | `NodeList` |
| `ListTools` | Enumerates MCP-compliant capabilities. | `CapabilityMsg`| `ToolSet` |

---

## 4. Core Data Types

### TaskState (`LN`)
The central state object representing a unit of work.
*   `Tag 1`: `id` (String) - Global unique identifier.
*   `Tag 6`: `status` (Enum) - {QUEUED, PLANNING, EXECUTING, COMPLETED, ERROR}.
*   `Tag 7`: `title` (String) - Human-readable task name.
*   `Tag 13`: `context_handles` (Repeated HandleId) - Pointers to sharded assets.
*   `Tag 17`: `environment` (Map) - Partitioned runtime variables.

### OpaqueHandle (`hdl`)
A cryptographic pointer that represents a sharded asset.
*   `id`: String identifier.
*   `is_partitioned`: Boolean (Must be true for cluster execution).
*   `target_nodes`: Repeated Integer (Ids of cluster nodes holding fragments).

---

## 5. Execution Runtime (Secure VM)

The runtime environment provides an isolated bash-compatible shell for autonomous validation.

*   **Ingress:** Master Handle + Differential Patch.
*   **Egress:** Bidirectional `stdout`/`stderr` stream.
*   **Verification:** The runtime generates a success attestation upon task completion.

---

## 6. Security & Integrity Layer

### SafeValue Sanitization
All incoming UI fragments are processed through a strictly typed sanitization pipeline (`SafeHtml`). This ensures that autonomous bot outputs cannot execute malicious scripts or manipulate the host shell.

### Handshake Proxying
The system supports **Uplink Signaling**. The browser acts as a cryptographic co-processor, proxying TLS handshakes to the Forwarder Node to establish secure connections without local key exposure.
