/**
 * MPCAuth Sharding Helper (Recovered & Modernized)
 * Ported from legacy sharding_helper.py logic.
 * 
 * This module implements Shamir's Secret Sharing over the Mersenne Prime field (2^127 - 1).
 * It is designed to work with the JesseQ/MPCAuth backend.
 */

const MPCAuth_SSS = {
    // Mersenne Prime: 2^127 - 1
    PRIME: (1n << 127n) - 1n,

    /**
     * Converts a string (e.g., email) to a BigInt.
     */
    stringToBigInt(str) {
        const encoder = new TextEncoder();
        const bytes = encoder.encode(str);
        let hex = '';
        for (const byte of bytes) {
            hex += byte.toString(16).padStart(2, '0');
        }
        return BigInt('0x' + hex);
    },

    /**
     * Converts a BigInt back to a string.
     */
    bigIntToString(bn) {
        let hex = bn.toString(16);
        if (hex.length % 2 !== 0) hex = '0' + hex;
        const bytes = new Uint8Array(hex.match(/.{1,2}/g).map(byte => parseInt(byte, 16)));
        return new TextDecoder().decode(bytes);
    },

    /**
     * Creates T-of-N shards.
     */
    createShards(secretStr, threshold, totalNodes) {
        const secret = this.stringToBigInt(secretStr);
        if (secret >= this.PRIME) {
            throw new Error("Secret is too large for the prime field. Consider chunking.");
        }

        // Generate polynomial coefficients [a0, a1, ..., aT-1]
        // a0 is the secret.
        const coeffs = [secret];
        for (let i = 1; i < threshold; i++) {
            const randBytes = new BigUint64Array(2);
            window.crypto.getRandomValues(randBytes);
            const randCoeff = (randBytes[0] << 64n | randBytes[1]) % this.PRIME;
            coeffs.push(randCoeff);
        }

        const shards = [];
        for (let i = 1; i <= totalNodes; i++) {
            const x = BigInt(i);
            let y = 0n;
            let xPow = 1n;

            for (const coeff of coeffs) {
                y = (y + (coeff * xPow)) % this.PRIME;
                xPow = (xPow * x) % this.PRIME;
            }

            shards.push({
                x: i,
                y: y.toString(16) // Hex string for easy transport
            });
        }

        return shards;
    },

    /**
     * Reconstructs the secret from shards (for testing/verification).
     * Note: In production MPCAuth, reconstruction never happens in one place.
     */
    reconstruct(shards) {
        let secret = 0n;

        for (let i = 0; i < shards.length; i++) {
            let numerator = 1n;
            let denominator = 1n;

            for (let j = 0; j < shards.length; j++) {
                if (i === j) continue;
                
                const xi = BigInt(shards[i].x);
                const xj = BigInt(shards[j].x);

                numerator = (numerator * (0n - xj)) % this.PRIME;
                denominator = (denominator * (xi - xj)) % this.PRIME;
            }

            // Modular inverse using Fermat's Little Theorem (prime field)
            const inv = this.modInverse(denominator, this.PRIME);
            const lagrange = (BigInt('0x' + shards[i].y) * numerator * inv) % this.PRIME;
            secret = (secret + lagrange) % this.PRIME;
        }

        // Ensure result is positive
        return this.bigIntToString((secret + this.PRIME) % this.PRIME);
    },

    modInverse(a, p) {
        return this.power(a, p - 2n, p);
    },

    power(base, exp, mod) {
        let res = 1n;
        base = base % mod;
        while (exp > 0n) {
            if (exp % 2n === 1n) res = (res * base) % mod;
            base = (base * base) % mod;
            exp = exp / 2n;
        }
        return res;
    }
};

// Export for use in dashboard
if (typeof window !== 'undefined') {
    window.MPCAuth_SSS = MPCAuth_SSS;
}
