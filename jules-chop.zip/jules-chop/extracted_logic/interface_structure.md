# Extended RPC Interface Structure

This document provides a detailed map of the RPC services, methods, and message structures extracted from the recovered frontend.

## Services

### SweBotService (`/SweBotService`)
Primary service for task management and bot interaction.

| Method | Descriptor | Req | Resp | Notes |
|:---|:---|:---|:---|:---|
| `CreateTask` | `Rja83d` | `zN` | `_.gO` | |
| `GetTask` | `n74qPd` | `MN` | `lO` | |
| `ListTasks` | `p1Takd` | `TN` | `_.oO` | |
| `UpdateUserSettings` | `GCDTBd` | `NW` | `MW` | |
| `CheckGitHubQuota` | `gV7IZe` | `u5a` | `z5a` | |
| `ListBranchNodes` | `c9RQT` | `v5a` | `B5a` | |
| `UpsertSource` | `VBvjpf` | `w_a` | `_.LP` | |
| `ListAuthorizedAccounts`| `G6wZ6` | `Qcb` | `Scb` | |

### SweBot1pService (`/SweBot1pService`)
First-party internal service extensions.

| Method | Descriptor | Req | Resp | Notes |
|:---|:---|:---|:---|:---|
| `CreateTask` | `m1Ohpb` | `zN` | `_.gO` | |
| `GetTask` | `EJrFmf` | `MN` | `lO` | |
| `GetTaskUsage` | `eNO9ve` | `kO` | `jO` | |
| `SearchContext` | `D2oHCd` | `q5a` | `p5a` | |
| `CodeSearch` | `C8aPU` | `ODa` | (anon) | |
| `CheckUserOptions` | `y0MC8` | `_.N5a` | `M5a` | |
| `ListRoleAccounts` | `n0WcTc` | `I5a` | `X5a` | |

### ContextService (`/ContextService`)
Service for managing user and tool context.

| Method | Descriptor | Req | Resp | Notes |
|:---|:---|:---|:---|:---|
| `GetContext` | `z0LDdf` | `_.kS` | `_.gPa` | |
| `ListToolProviders` | `fI0vqb` | (anon) | `_.lS` | |
| `ListTools` | `h2scJf` | (anon) | `_.nS` | |
| `CompleteOAuth` | `V7QkPe` | (anon) | (anon) | |

### InternalPeopleService (`/InternalPeopleService`)
| Method | Descriptor | Req | Resp |
|:---|:---|:---|:---|
| `GetPeople` | `o30O0e` | `Cqa` | `wqa` |

## Message Structures (Tags)

### `Task` (`_.gO` / `_.LN`)
| Tag | Field | Type | Notes |
|:---|:---|:---|:---|
| `1` | `id` | string | |
| `7` | `title` | string | |
| `13` | `metadata` | repeated | |
| `17` | `environment` | repeated | |
| `6` | `status` | enum | See `TaskStatus` |

### `Source` (`_.LP` / `_.lP`)
| Tag | Field | Type | Notes |
|:---|:---|:---|:---|
| `1` | `id` | string | e.g., "github/owner/repo" |
| `2` | `display_name` | string | |
| `3` | `timestamp` | `vA` | |
| `5` | `metadata` | repeated | |
| `6` | `context` | repeated | |

### `UserSettings` (`_.QN` / `MW`)
| Tag | Field | Type | Notes |
|:---|:---|:---|:---|
| `1` | `user_id` | string | |
| `2` | `email` | string | |
| `3` | `preferences` | repeated | |
| `6` | `quota_limit` | int32 | |
| `15` | `feature_flags` | repeated | |

### `Branch` (`_.$y`)
| Tag | Field | Type |
|:---|:---|:---|
| `1` | `name` | string |

### `RepoInfo` (`_.Vy`)
| Tag | Field | Type |
|:---|:---|:---|
| `2` | `repo_name` | string |
| `3` | `repo_owner` | string |

## Shared Objects

### `Timestamp` (`_.vA`)
- `1`: seconds (int64)
- `2`: nanos (int32)

### `Status` (`_.Iy`)
- `1`: code (int32)
- `2`: message (string)
