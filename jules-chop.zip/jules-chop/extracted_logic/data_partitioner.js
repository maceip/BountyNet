/**
 * Data Partitioner (Engineering Blueprint)
 * Implements a t-of-n partitioning scheme for distributed data processing.
 */

const DataPartitioner = {
    // Large Prime Field for distributed arithmetic
    FIELD_PRIME: (1n << 127n) - 1n,

    stringToBigInt(str) {
        const encoder = new TextEncoder();
        const bytes = encoder.encode(str);
        let hex = '';
        for (const byte of bytes) {
            hex += byte.toString(16).padStart(2, '0');
        }
        return BigInt('0x' + hex);
    },

    bigIntToString(bn) {
        let hex = bn.toString(16);
        if (hex.length % 2 !== 0) hex = '0' + hex;
        const bytes = new Uint8Array(hex.match(/.{1,2}/g).map(byte => parseInt(byte, 16)));
        return new TextDecoder().decode(bytes);
    },

    /**
     * Creates T-of-N partitions for cluster distribution.
     */
    createPartitions(dataStr, threshold, totalNodes) {
        const dataVal = this.stringToBigInt(dataStr);
        if (dataVal >= this.FIELD_PRIME) {
            throw new Error("Data block too large for current field.");
        }

        const coeffs = [dataVal];
        for (let i = 1; i < threshold; i++) {
            const randBytes = new BigUint64Array(2);
            window.crypto.getRandomValues(randBytes);
            const randCoeff = (randBytes[0] << 64n | randBytes[1]) % this.FIELD_PRIME;
            coeffs.push(randCoeff);
        }

        const partitions = [];
        for (let i = 1; i <= totalNodes; i++) {
            const x = BigInt(i);
            let y = 0n;
            let xPow = 1n;

            for (const coeff of coeffs) {
                y = (y + (coeff * xPow)) % this.FIELD_PRIME;
                xPow = (xPow * x) % this.FIELD_PRIME;
            }

            partitions.push({
                node_id: i,
                fragment: y.toString(16)
            });
        }

        return partitions;
    }
};

if (typeof window !== 'undefined') {
    window.DataPartitioner = DataPartitioner;
}
