# Bountynet Distributed S.W.E. Bot: Architectural Brief

## 1. Executive Summary
Bountynet is a high-performance, distributed software engineering (S.W.E.) platform. It leverages a "Local-First" data ingress model coupled with a "Parallel Cluster" execution environment. The system is designed to provide autonomous code analysis, fix generation, and validation while maintaining strict data partitioning between the user's local context and the remote compute cluster.

## 2. System Architecture: "The Data Forge"

The system is comprised of four logical layers:

### A. Ingress Layer (Local Context & Uplink Bridge)
*   **Technology:** File System Access API + iframe-based Handshake Proxy.
*   **Function:** Recursively reads local directories and establishes a secure "Uplink Bridge" to the Forwarder Node.
*   **Uplinkability:** The layer acts as a cryptographic co-processor, performing **Handshake Proxying**. It allows the browser to jointly establish TLS sessions with the Parallel Cluster without local plaintext key exposure.
*   **Partitioning:** Before transmission, the archive is processed by the **Data Partitioner**, which fragments the metadata into a t-of-n distribution for the cluster.

### B. The Forge (Background Processing)
*   **Technology:** Web Workers (multi-threaded).
*   **Function:** CPU-intensive tasks—such as zipping, fragmenting, and large-number arithmetic—are offloaded to background threads. This ensures a "Champagne" (zero-latency) UI experience.

### C. The Bridge (API Client)
*   **Technology:** Typed TypeScript RPC Client.
*   **Function:** Communicates with the Parallel Cluster using established Boq/Closure RPC descriptors. It handles the serialization of "Opaque Handles" rather than raw data.

### D. The Canvas (UI/UX)
*   **Technology:** React + Monaco Editor + Markdown-it.
*   **Function:** Provides a high-fidelity workspace for code editing, side-by-side diff review, and live terminal streaming from the execution runtime.

---

## 3. Data Flow: "Bootstrap & Differential"

The system utilizes a two-stage synchronization protocol:

1.  **The Bootstrap (Initial Sync):**
    *   The entire local repository context is zipped and partitioned.
    *   The fragments are distributed across the Parallel Cluster.
    *   A **Master Handle ID** is generated, representing the base state of the task.

2.  **The Differential (Iterative Execution):**
    *   The bot proposes modifications (Patches).
    *   The **Context Manager** calculates a "High-Fidelity Diff" between the current VFS state and the proposal.
    *   Only the **Partitioned Patch** and the Master Handle are transmitted for execution.

---

## 4. API & Interface Specifications (RPC)

Based on the recovered platform descriptors, the following interfaces are implemented:

### SweBotService (`/SweBotService`)
| Method | RPC Code | Request | Response | Description |
|:---|:---|:---|:---|:---|
| `CreateTask` | `Rja83d` | `zN` | `_.gO` | Initializes a new autonomous fix task. |
| `GetTask` | `n74qPd` | `MN` | `lO` | Retrieves task status and current VFS state. |
| `ListTasks` | `p1Takd` | `TN` | `_.oO` | Enumerates active and archived tasks. |
| `UpdateUserSettings` | `GCDTBd` | `NW` | `MW` | Synchronizes local preferences with the cluster. |

### ContextService (`/ContextService`)
*   **Protocol:** **Model Context Protocol (MCP)**.
*   **Function:** Manages the lifecycle of MCP remote servers and local tool providers.
*   **Uplink:** Uses the Uplink Bridge to proxy `mcp_tool_called` events to the Parallel Cluster.
*   **Methods:**
| Method | RPC Code | Description |
|:---|:---|:---|
| `GetContext` | `z0LDdf` | Retrieves opaque MCP handles for active context. |
| `ListToolProviders` | `fI0vqb` | Identifies active MCP remote servers and API nodes. |
| `ListTools` | `h2scJf` | Enumerates available MCP-compliant execution capabilities. |

---

## 5. Execution Runtime (The Isolated VM)
Code execution occurs in a **Remote Isolated Runtime**. 
*   **Capability:** Full shell access, test runner integration, and build system orchestration.
*   **Streaming:** Live `stdout`/`stderr` is piped back to the frontend via a **StatefulExecutionInterface**, allowing for real-time validation of autonomous fixes.
*   **Security:** Execution is performed against the partitioned context, ensuring no single compute node holds the full un-fragmented repository state.

---

## 6. Security Engineering & "Deep Plumbing"

### A. The SafeValue Sanitization System
To prevent Cross-Site Scripting (XSS) and code injection from autonomous bot outputs, the "Canvas" layer implements a strict **SafeValue** architecture:
*   **Module:** `safevalues_raw` (replicated from `goog.html.SafeHtml`).
*   **Sanitization:** Every piece of incoming Markdown or HTML is processed via `sanitizeHtmlToFragment`. It strips all non-whitelisted tags and "on*" event handlers.
*   **Shadow DOM Isolation:** Rendered fragments are attached to a `closed` Shadow Root (`safevalues-with-css`). This ensures that bot-generated styles (from Pikchr or Graphviz) cannot leak into or manipulate the host dashboard UI.
*   **Type Safety:** The system globally intercepts `setElementInnerHtml` to *only* allow `SafeHtml` objects, effectively "locking" the DOM against raw string injection.

### B. The Iframe Sandbox System
For components requiring higher isolation (such as the **Uplink Bridge** and **Legacy Diff Views**), the system utilizes a multi-layered Iframe strategy:
*   **Attributes:** `sandbox="allow-scripts allow-forms allow-popups-to-escape-sandbox"`.
*   **Intent-Based Loading:** Uses `setIframeSrcdocWithIntent` to dynamically provision sandboxes with a "None" Content Security Policy (CSP) by default, only elevating permissions for specific, sharded tasks.

### C. Emscripten & WebAssembly (G3mark Engine)
The core "Intelligence" for text processing and diagram rendering is offloaded to a 1.5MB Wasm module (`jukeswasm`):
*   **Compilation:** Compiled from C++ sources using **Emscripten**.
*   **Included Libraries:** CMark (Markdown), RE2 (Regex), MathJax (TeK), Graphviz/Pikchr (Vector Diagrams), and ICU (Unicode normalization).
*   **Runtime Environment:** Operates in a virtualized "web_user" POSIX-like environment (`/home/web_user`). It uses a **Memory Bridge** (`Jb`) to communicate with the JavaScript main thread via `TextDecoder` and `BigInt` word-mapping.
*   **Performance:** By moving regex matching (RE2) and diagram layout (Graphviz) to Wasm, the system achieves near-native performance for complex UI updates without blocking the browser's event loop.

## 7. Development Roadmap: Path to Feature Parity
The primary objective is to reach full functional parity with the recovered 2018-2019 "Jules" platform before introducing advanced optimizations.

1.  **Phase 1: Core Heavy Machinery [COMPLETED]**
    *   Virtual File System (VFS) and Bootstrap zipping.
    *   Multi-threaded Data Partitioner for cluster distribution.
    *   Modern Monaco-based Code and Diff editors.

2.  **Phase 2: Service & Runtime Parity [READY]**
    *   Full implementation of `SweBotService` and `ContextService` RPC bridges.
    *   Bidirectional streaming for the Remote Isolated Runtime (Terminal).
    *   Integration of the G3mark Wasm engine for high-fidelity Markdown/Diagram rendering.

3.  **Phase 3: Parallel Cluster Integration [IN-PROGRESS]**
    *   End-to-end synchronization between local VFS and cluster state.
    *   Handshake Proxying for secure uplink to external repositories.
    *   Automated verification loop (Plan -> Act -> Validate).

---

## 8. Future Research (Beyond Parity)
Once baseline parity is established and validated by the engineering team, the following technological leaps may be explored:
*   **WebGPU Acceleration:** Offloading large-number partitioning arithmetic and local embedding generation to the GPU.
*   **Zero-Knowledge Proofs (ZKP):** Integrating the JesseQ framework for mathematical verification of bot-generated fixes.
*   **Merkle-DAG Synchronization:** Transitioning from ZIP-based bootstrapping to O(1) hash-based state synchronization.
